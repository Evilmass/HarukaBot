from packaging.version import Version

__version__ = "1.6.0post5"
VERSION = Version(__version__)
